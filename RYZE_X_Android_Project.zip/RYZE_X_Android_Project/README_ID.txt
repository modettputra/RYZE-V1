RYZE X — proyek Android native awal

Fitur yang sudah dibuat:
- Mendeteksi aplikasi yang memiliki ikon peluncur (launcher) di Android.
- Menampilkan ikon dan nama aplikasi.
- Pencarian aplikasi.
- Tombol BUKA untuk menjalankan aplikasi terpilih.
- Antarmuka gelap biru elektrik.

Batasan:
- Android membatasi visibilitas paket. Proyek ini hanya meminta daftar aplikasi yang menyediakan aktivitas MAIN/LAUNCHER, bukan memindai seluruh paket tersembunyi.
- Ini belum mengontrol GPU, RAM, suhu, FPS, refresh rate, atau jaringan. Fitur tersebut memerlukan dukungan/izin sistem khusus dari vendor.
- Ini adalah SOURCE PROJECT, bukan APK yang sudah ter-build.

Cara build:
1. Ekstrak ZIP di komputer.
2. Buka folder RYZE_X_Android_Project melalui Android Studio.
3. Tunggu Gradle Sync selesai.
4. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK hasil build biasanya ada di app/build/outputs/apk/debug/app-debug.apk.

Target SDK 35 (Android 15), minimum Android 6.0.
