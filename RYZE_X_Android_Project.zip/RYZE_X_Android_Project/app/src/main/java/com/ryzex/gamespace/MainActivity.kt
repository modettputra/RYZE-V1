package com.ryzex.gamespace

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import android.text.Editable
import android.text.TextWatcher

data class AppEntry(val label: String, val packageName: String)

class MainActivity : Activity() {
    private val cyan = Color.rgb(85, 226, 255)
    private val apps = mutableListOf<AppEntry>()
    private lateinit var list: LinearLayout
    private lateinit var search: EditText
    private lateinit var count: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(5, 11, 24)
        window.navigationBarColor = Color.rgb(5, 11, 24)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 22, 20, 20)
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(5, 11, 24), Color.rgb(8, 31, 57), Color.rgb(5, 11, 24))
            )
        }
        val title = TextView(this).apply {
            text = "RYZE X  ⚡"
            textSize = 26f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = .12f
        }
        page.addView(title)
        page.addView(label("GAME SPACE • ANDROID", 10f, cyan).apply { setPadding(0, 4, 0, 16) })

        val hero = TextView(this).apply {
            text = "ELECTRIC ARENA\\n⚡"
            gravity = Gravity.CENTER
            textSize = 25f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(12, 48, 77), cyan, 20)
            setPadding(12, 20, 12, 20)
        }
        page.addView(hero, LinearLayout.LayoutParams(-1, 130).apply { bottomMargin = 16 })

        count = label("MEMUAT APLIKASI…", 12f, cyan)
        page.addView(count)
        search = EditText(this).apply {
            hint = "Cari aplikasi…"
            setSingleLine(true)
            textSize = 14f
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            background = rounded(Color.rgb(12, 29, 49), Color.rgb(35, 83, 117), 14)
            setPadding(14, 8, 14, 8)
        }
        page.addView(search, LinearLayout.LayoutParams(-1, 52).apply { topMargin = 10; bottomMargin = 10 })

        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val note = label("RYZE X menampilkan aplikasi yang menyediakan ikon peluncur. Fitur booster GPU/FPS tidak tersedia melalui aplikasi biasa.", 10f, Color.LTGRAY)
        note.setPadding(0, 12, 0, 0)
        page.addView(note)

        setContentView(page)
        loadApps()
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { renderApps(s?.toString().orEmpty()) }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun loadApps() {
        apps.clear()
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val results = packageManager.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        for (item in results) {
            val packageName = item.activityInfo.packageName
            if (packageName == packageNameOfThisApp()) continue
            val label = item.loadLabel(packageManager).toString()
            if (apps.none { it.packageName == packageName }) apps.add(AppEntry(label, packageName))
        }
        apps.sortBy { it.label.lowercase() }
        count.text = "APLIKASI TERDETEKSI • ${apps.size}"
        renderApps("")
    }

    private fun packageNameOfThisApp() = packageName

    private fun renderApps(query: String) {
        list.removeAllViews()
        val filtered = apps.filter { it.label.contains(query, true) }
        if (filtered.isEmpty()) {
            list.addView(label("Tidak ada aplikasi yang cocok.", 13f, Color.LTGRAY))
            return
        }
        filtered.forEach { app ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(12, 9, 12, 9)
                background = rounded(Color.rgb(12, 31, 52), Color.rgb(28, 68, 99), 14)
            }
            val icon = try { packageManager.getApplicationIcon(app.packageName) } catch (_: Exception) { null }
            val image = ImageView(this).apply { setImageDrawable(icon) }
            row.addView(image, LinearLayout.LayoutParams(42, 42))
            val name = TextView(this).apply {
                text = app.label
                textSize = 14f
                setTextColor(Color.WHITE)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(12, 0, 4, 0)
            }
            row.addView(name, LinearLayout.LayoutParams(0, -2, 1f))
            val open = Button(this).apply {
                text = "BUKA"
                textSize = 10f
                setTextColor(Color.WHITE)
                background = rounded(Color.rgb(0, 111, 165), cyan, 12)
                setOnClickListener { launchApp(app.packageName) }
            }
            row.addView(open, LinearLayout.LayoutParams(82, 42))
            list.addView(row, LinearLayout.LayoutParams(-1, 62).apply { bottomMargin = 8 })
        }
    }

    private fun launchApp(pkg: String) {
        val launch = packageManager.getLaunchIntentForPackage(pkg)
        if (launch != null) startActivity(launch)
        else Toast.makeText(this, "Aplikasi tidak bisa dibuka dari launcher.", Toast.LENGTH_SHORT).show()
    }

    private fun label(textValue: String, size: Float, color: Int) = TextView(this).apply {
        text = textValue
        textSize = size
        setTextColor(color)
    }

    private fun rounded(color: Int, stroke: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
        setStroke(1, stroke)
    }
}
